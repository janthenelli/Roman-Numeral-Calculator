module edu.mccc.cos210.hailcaesar {
	requires java.desktop;
}